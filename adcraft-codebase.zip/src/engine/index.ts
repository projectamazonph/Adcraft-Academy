/**
 * AdCraft: Evaluation Engine — Barrel Export
 *
 * This is the public API for the Pure TypeScript Deterministic Engine.
 * All engine functions are pure, deterministic, and have zero framework dependencies.
 *
 * Usage:
 *   import { calculateAcos, evaluateStrTriage, createSimulationState } from '@/engine';
 */

// Types — all domain types for the engine
export type {
  PpcMetrics,
  PpcRawData,
  PpcMetricThresholds,
  PpcMetricsHealth,
  MetricHealthStatus,
  PpcFormula,
  FormulaUnit,
  FormulaCategory,
  FormulaInput,
  FormulaResult,
  StrAction,
  SearchTermEntry,
  StrUserAction,
  StrExpectedAction,
  StrActionEvaluation,
  StrTriageEvaluation,
  MatchType,
  CampaignType,
  TargetingType,
  BidStrategy,
  CampaignKeyword,
  CampaignStructure,
  SimProduct,
  CampaignBuilderCriteria,
  CriterionResult,
  CampaignBuilderEvaluation,
  BidScenario,
  BidMarketContext,
  BidDecision,
  BidDecisionEvaluation,
  BidElevatorEvaluation,
  SimulationType,
  SimulationDifficulty,
  SimulationContext,
  SimulationState,
  UserAction,
  CampaignBuilderState,
  BidElevatorState,
  StrTriageState,
  SimulationEvaluator,
  ValidationResult,
  ValidationError,
  ValidationWarning,
  SimulationEvaluation,
  XpRewards,
  LevelDefinition,
  UserProgress,
  AiMentorContext,
  PpcRule,
  AiMentorMessage,
} from './types';

// Type guards
export {
  isCampaignBuilderEvaluation,
  isBidElevatorEvaluation,
  isStrTriageEvaluation,
} from './types';

// Formulas — PPC metric calculations
export {
  calculateCpc,
  calculateAcos,
  calculateTacos,
  calculateRoas,
  calculateCtr,
  calculateConversionRate,
  calculateBreakEvenAcos,
  calculateMaxCpc,
  calculateAov,
  calculateImpressionShare,
  calculateMetrics,
  calculateMetricsWithTacos,
  assessMetricHealth,
  assessMetricsHealth,
  computeFormula,
  formatFormulaOutput,
  getFormulasForModule,
  getFormulaBySlug,
  PPC_FORMULAS,
} from './formulas';

// Evaluation — scoring engine for all simulations
export {
  evaluateStrTriage,
  previewStrTriageScore,
  previewCampaignBuilderScore,
  previewBidElevatorScore,
  validateCampaignBuilder,
  validateStrTriageActions,
  evaluateBidElevator,
} from './evaluation';

// Simulation — state lifecycle management
export {
  createSimulationState,
  startSimulation,
  pauseSimulation,
  resumeSimulation,
  submitSimulation,
  addCampaign,
  updateCampaign,
  addKeyword,
  removeKeyword,
  initBidElevatorScenarios,
  recordBidDecision,
  initStrTriageSearchTerms,
  recordStrAction,
  getElapsedSeconds,
  getActionCount,
  serializeSimulationState,
  deserializeSimulationState,
  isSimulationComplete,
} from './simulation';
